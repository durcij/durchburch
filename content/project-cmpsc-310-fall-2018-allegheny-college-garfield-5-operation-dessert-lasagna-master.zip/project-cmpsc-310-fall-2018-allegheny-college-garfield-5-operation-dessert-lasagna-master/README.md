
# The Watchers
By Garfield 5: Operation Dessert Lasagna: Jordan Durci, Noah Stape, and Alex Yarkosky

## About the Game

The Watchers are a race of tiny people whose duty it is to guard the Seeds of Evil to ensure they never take root and corrupt the world.  Two of the Watchers were attacked and bound up in the webbing of a Grumperfly, a corrupted butterfly.  While they were unconscious, the seeds they were tasked with guarding went missing.  Now they must do what they can to reclaim them, even if their actions are limited.  Play as Lloyd, the blue Watcher whose arms are bound, but whose massive reserves of energy leave him constantly moving (at high speeds, no less), and his brother Armin, whose legs are bound, making him unable to move without leaping into thw air, but whose strength leaves him capable of punching enemies out of his way.  Face five types of enemies, Grums, Grumpas, Grumperflies, Snüds, and Slüds, and reclaim the lost seeds before one can sprout into a Germ of Evil.  Play with a friend on the same keyboard for the best multiplayer gaming experience to come from CMPSC 310 this semester!

## Download

This repository can be downloaded from the terminal with the following command:

`git clone https://github.com/Allegheny-College-Science-310-F2018/project-cmpsc-310-fall-2018-allegheny-college-garfield-5-operation-dessert-lasagna.git`

Otherwise, you can manually download above as a ZIP file.

## Installation

If used the command above in a terminal, as long as Unity is installed, you will be able to open the project within Unity.

If you manually downloaded the ZIP file instead, you will just need to additionally unzip it and then have Unity installed in order to be able to open the project with it.

## Running

After opening the project folder, `Operation Dessert Lasagna`, within the `src` folder, in Unity, it will be possible to hit the play button within Unity to play the game.
