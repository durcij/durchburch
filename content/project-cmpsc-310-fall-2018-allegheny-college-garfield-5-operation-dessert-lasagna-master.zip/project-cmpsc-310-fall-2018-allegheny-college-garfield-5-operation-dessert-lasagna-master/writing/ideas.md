# Project Idea(s)
# Group members Jordan Durci, Noah Stape, and Alex Yarkosky

## Ideas

### Jordan's Idea

#### Platformer Game

A relatively simple game to make, but one that requires a lot of different AI techniques.  It would also be good way to explore Unity2D.  With my experience in spriting, it could be a bit easier to have unique and interesting graphics.

### Noah's Idea

#### THEATER Lights

I came up with the idea to create a database of different incandescent theatre lights turning on and off. We could then use AI to create a generic or average light(fade/turn on) and create a simulation of this for led lights. We could use different functions of OpenCV to make this a reality.

### Alex's Idea

#### Spatial Model Extension

An extension of the spatial model from lab, this premise has a hunter actually moving around to detect and then kill the multiple, various prey present. Potentially could be extended into a game where you play as one of the prey and try to avoid getting killed (but most likely forced to move so that you can still be detected with the user just choosing the direction of movement).
