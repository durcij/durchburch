# Status Update by Jordan Durci and Marcus Davenport

As it stands, Fate Escape is functional, but only has two areas.  It has some
helpful functions such as Options, which lists the available commands for a
given area.  We still have to incorporate two more methods and one more class,
but that shouldn't be too difficult.  We've got the main block of code that we
can use to build a bunch of new areas built at this point, so we're in the
clear when it comes to the main body of the program.
