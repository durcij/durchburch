# Proposal by Jordan Durci and Marcus Davenport

We have chosen to do the option Story Telling. We want the user to chose its
fate, by user input. The user will wake up in a forest. There will be 3
opitions the user will be able to chose from. One option is description. The
description will display a brief message describing the users surrondings. The
other 2 opitions will let the user either chose left or right. The left opition
will take you down a path overgrown. The right will take you down a clear path.
If you chose the overgrown path you will be forced to either press a button or
go back to the start. If you press the button nothing will happen. Once
description by using conditional logic we will be able to predict what gqipfate
the user will chose to follow. First thing we will do is construct a main class
in which we will put the code we chose. Second will create a class with the
data output for the user.
