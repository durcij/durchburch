# Reflection by Jordan Durci and Marcus Davenport

The input for Fate Escape is entered in the terminal window. Its input is
mostly simple strings stored as names, used as cheat codes, or used as
commands. One instance has the user enter a review as long as they choose as
input. The output is a series of pieces of dialogue and other such strings that
display in the terminal window. The commands behave in ways that lead to
changes in some ints and bytes that store that are picked up by if statements.
Those if statements determine (in the case of the ints), the location the
player is in, and (in the case of the bytes) whether or not certain game
functions (such as locks) are engaged. There were some difficulties in getting
the areas to change correctly, but the use of break statements and while loops
came in handy in solving those issues.

Overall, I think that our teamwork went pretty well. We didn't necessarily
switch back and forth with every commit, choosing to switch when comfortable.
In some cases I committed twice in a row because I was working at an odd time,
spur of the moment, or because I committed to bypass issues early on when we
were having when Marcus tried to commit.

The third paragraph will discuss the second team member's insights. Delete this
paragraph so that the check will fail and the student will be reminded to add
it.
