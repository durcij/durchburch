# Report by Marcus and Jordan

We have used 3 java files to create our program. In the first file
FateEscapeManager we create our Arraylist. By using while statemtents we were
succesfully able to pull our locations and Dialouge text files into The
FateEscape file. Within the file we use 2 data types. One is an int and the
second one is a string. In the second file FateEscape we used majority of our
code. We used 2 methods in our main file allowing us to pull from files
FateWorld and FateEscape.

The third file FateWorld contains 3 data types, 2 strings Byte and Int. In this
file we successfully implemented a cheat code for those players who do not feel
like working their way through. Every step we took, we tested it to make sure
there were no errors. If there were errors we struggled and fought to make sure
we resolved them. In the end we have robust program. We really enjoyed creating
this program.


