package labeleven;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;


/**This class will allow us to read in our input files*/

public class FateEscapeManager {

  // Reads in the locations to construct an array.
  public static String[] readLocations() throws IOException {
    String[] locationArray = new String[8];
    int startLocation = 0;
    Scanner fileScannerL = new Scanner(new File("input/locations.txt"));
    while(fileScannerL.hasNext()) {
      String locationLine = fileScannerL.nextLine();
      locationArray[startLocation] = locationLine;
      startLocation++;
    }
    return locationArray;
  }
// Reads in the dialogue to construct an array.
  public static String[] readDialogue() throws IOException {
    String[] dialogueArray = new String[22];
    int startDialogue = 0;
    Scanner fileScannerD = new Scanner(new File("input/dialogue.txt"));
    while(fileScannerD.hasNext()) {
      String dialogueLine = fileScannerD.nextLine();
      dialogueArray[startDialogue] = dialogueLine;
      startDialogue++;
    }
    return dialogueArray;
  }
}
