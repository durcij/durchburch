package labeleven;

import java.io.*;
import java.util.Scanner;

/**
 * This class deals with minor side functions of FateEscape.
 *
 * <p>Bugs: This program has no known bugs.
 *
 * @author Jordan Durci and Marcus Davenport
 */

public class FateWorldData {
  //Takes in a player name.
  public static String playerName() {
    Scanner nameScan = new Scanner(System.in);
    System.out.println("Please enter your name.");
    String name = nameScan.nextLine();
    return name;
  }
  public String playerReview() throws IOException {
    String file = "currentReview.txt";
    Scanner reviewScan = new Scanner(System.in);
    FileWriter fw = new FileWriter (file);
    BufferedWriter bw = new BufferedWriter (fw);
    PrintWriter outFile = new PrintWriter (bw);
    outFile.print(reviewScan.nextLine());
    outFile.println();
    outFile.close();
    file = "currentReview.txt";
    return file;
  }
  public static int cheatCode() {
    Scanner codeScan = new Scanner(System.in);
    System.out.println("Enter a cheat code if you so choose.");
    String code = codeScan.nextLine();
    int cheatArea = 0;
    if (code.equals("Marcus") || code.equals("Jordan")) {
      cheatArea = 7;
    }
    return cheatArea;
  }
}
