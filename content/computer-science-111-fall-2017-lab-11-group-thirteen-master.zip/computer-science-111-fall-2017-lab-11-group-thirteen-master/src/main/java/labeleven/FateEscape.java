package labeleven;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Scanner;

/** this class will produce a game called Fate Escape.
 *
 */

public class FateEscape {

  public static void main(String[] args) throws IOException {
    // Display the name of the programmers and date
    System.out.println("Jordan Durci and Marcus Davenport " + new Date());
    //Sets up the arrays
    FateEscapeManager manager = new FateEscapeManager();
    String[] loc = manager.readLocations();
    String[] dia = manager.readDialogue();
    //Takes in the name.
    FateWorldData data = new FateWorldData();
    String player = data.playerName();
    int cheat = data.cheatCode();

    // Display Greeting message for Fate Escape
    System.out.println("\nWelcome to Fate Escape, " + player + ". Can you find your way out? \nTo see possible commands type 'o'");
    System.out.println("\n" + dia[0]);
    int area = cheat;
    byte foundButton = 0;
    byte foundBook = 0;
    byte readBook = 0;
    byte unlock = 0;
    byte lock = 0;
    Scanner userControl = new Scanner(System.in);
      while (area >= (-1)) {
        // GROVE
        if (loc[area].equals("0 Grove")) {
          System.out.println(dia[1]);
          while (userControl.hasNext()) {
            String command = userControl.nextLine();
            if (command.equals("Inspect")) {
              System.out.println(dia[2]);
            } else if (command.equals("Left")) {
                area = 1;
                System.out.println("You go left.");
                break;
            } else if (command.equals("Right")) {
                area = 3;
                System.out.println("You go right.");
                break;
            } else if (command.equals("o")) {
                System.out.println("Possible Commands: Inspect/Right/Left");
            }
          }
        }
        // PATH OVERGROWN
        if (loc[area].equals("1 Path Overgrown")) {
          System.out.println(dia[3]);
          while (userControl.hasNext()) {
          String command = userControl.nextLine();
          if (command.equals("Inspect")) {
            System.out.println(dia[4]);
          } else if (command.equals("Back")) {
              area = 0;
              System.out.println("You go back.");
              break;
          } else if (command.equals("Forward")) {
              area = 2;
              System.out.println("You go forward.");
              break;
          } else if (command.equals("o")) {
              System.out.println("Possible Commands: Inspect/Back/Forward");
          }
        }
      }
      // FALLEN TREE
      if (loc[area].equals("2 Fallen Tree")) {
        System.out.println(dia[5]);
        while (userControl.hasNext()) {
        String command = userControl.nextLine();
        if (command.equals("Inspect")) {
          System.out.println(dia[6]);
          foundButton = 1;
        } else if (command.equals("Back")) {
            area = 1;
            System.out.println("You go back.");
            break;
        } else if (command.equals("Push Button")) {
            lock = 1;
            System.out.println("You push the button.");
            System.out.println(dia[7]);
        } else if (command.equals("o")) {
            if (foundButton == 1) {
              System.out.println("Possible Commands: Inspect/Back/Push Button");
            } else {
              System.out.println("Possible Commands: Inspect/Back");
            }
          }
        }
      }
      // PATH CLEARED
      if (loc[area].equals("3 Path Cleared")) {
        System.out.println(dia[8]);
        while (userControl.hasNext()) {
          String command = userControl.nextLine();
          if (command.equals("Inspect")) {
            System.out.println(dia[9]);
          } else if (command.equals("Back")) {
              area = 0;
              System.out.println("You go back.");
              break;
          } else if (command.equals("Forward")) {
              area = 4;
              System.out.println("You go forward.");
              break;
          } else if (command.equals("o")) {
              System.out.println("Possible Commands: Inspect/Back/Forward");
          }
        }
      }
      // PATH SPLIT
      if (loc[area].equals("4 Path Split")) {
        System.out.println(dia[10]);
        while (userControl.hasNext()) {
          String command = userControl.nextLine();
          if (command.equals("Inspect")) {
            System.out.println(dia[11]);
          } else if (command.equals("Back")) {
              area = 3;
              System.out.println("You go back.");
          } else if (command.equals("Left")) {
              area = 5;
              System.out.println("You go left.");
              break;
          } else if (command.equals("Right")) {
              area = 6;
              System.out.println("You go right.");
              break;
          } else if (command.equals("o")) {
              System.out.println("Possible Commands: Inspect/Back/Right/Left");
          }
        }
      }
      // HOUSE
      if (loc[area].equals("5 House")) {
        System.out.println(dia[12]);
        while (userControl.hasNext()) {
          String command = userControl.nextLine();
          if (command.equals("Inspect")) {
            System.out.println(dia[13]);
            foundBook = 1;
          } else if (command.equals("Back")) {
              area = 4;
              System.out.println("You go back.");
              break;
          } else if (command.equals("Read Book")) {
              System.out.println(dia[14]);
              if (lock == 1) {
                System.out.println(dia[15]);
                area = 7;
              } else {
                readBook = 1;
              }
              break;
          } else if (command.equals("o")) {
              if (foundBook == 1) {
                System.out.println("Possible Commands: Inspect/Back/Read Book");
              } else {
                System.out.println("Possible Commands: Inspect/Back");
              }
            }
        }
      }
      // GATE
      if (loc[area].equals("6 Gate")) {
        System.out.println(dia[16]);
        while (userControl.hasNext()) {
          String command = userControl.nextLine();
          if (command.equals("Inspect")) {
            System.out.println(dia[17]);
          } else if (command.equals("Back")) {
              area = 4;
              System.out.println("You go back.");
              break;
          } else if (command.equals("Push Button")) {
              System.out.println(dia[18]);
              if (lock == 0) {
                System.out.println(dia[19]);
                unlock = 1;
              } else {
                System.out.println(dia[20]);
              }
              break;
          } else if (command.equals("Open Gate")) {
              System.out.println("You attempt to open the gate.");
              if (unlock == 0) {
                System.out.println("The gate is locked.");
              } else {
                System.out.println(dia[21]);
                area = 7;
              }
              break;
          } else if (command.equals("o")) {
              if (readBook == 1) {
                System.out.println("Possible Commands: Inspect/Back/Push Button/Open Gate");
              } else {
                System.out.println("Possible Commands: Inspect/Back/Open Gate");
            }
          }
        }
      }
      //EXIT
      //Isn't all that important, just a way to end the program.
      if (loc[area].equals("7 Exit")) {
        System.out.println("Thanks for playing Fate Escape!\nPlease write a review of how we did below.");
        String review = data.playerReview();
        System.out.println("Review Accepted.\nThank you.\nThe program will now close.");
        break;
      }
    }
  }
}
